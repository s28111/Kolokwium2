﻿using Kolokwium2.Models;
using Microsoft.EntityFrameworkCore;

namespace Kolokwium2.Contexts;

public class Kolokwium2Context : DbContext
{
  public Kolokwium2Context()
  {
    
  }

  public Kolokwium2Context(DbContextOptions<Kolokwium2Context> options) : base(options)
  {
    
  }

  public DbSet<Client> Clients { get;set; }
  public DbSet<Discount> Discounts { get;set; }
  public DbSet<Payment> Payments { get;set; }
  public DbSet<Sale> Sales { get;set; }
  public DbSet<Subscribtion> Subscribtions { get;set; }
}
