﻿using Kolokwium2.Models;

namespace Kolokwium2.DTOs;

public class SubscribtionDTO
{
    public int IdClient { get; set; }
    public int IdSubscribtion { get; set; } 
    public Payment Payment { get; set; }
}