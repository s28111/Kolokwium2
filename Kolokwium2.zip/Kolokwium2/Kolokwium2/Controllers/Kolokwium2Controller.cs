﻿using System.Runtime.InteropServices.JavaScript;
using Kolokwium2.Contexts;
using Kolokwium2.DTOs;
using Kolokwium2.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Kolokwium2.Controllers;

[Route("api/[controller]")]
[ApiController]
public class Kolokwium2Controller : ControllerBase
{
    private readonly Kolokwium2Context _context;

    public Kolokwium2Controller(Kolokwium2Context context)
    {
        _context = context;
    }

    [HttpGet("{idClient}")]
    public async Task<IActionResult> GetClientSubscribtions(int idClient)
    {
        var result = await _context.Clients
            .Include(c => c.Sales).ThenInclude(s => s.IdSubscribtionNavigation)
            .Include(c => c.Payments).ThenInclude(p => p.IdSubscribtionNavigation)
            .Where(c => c.IdClient == idClient).Select(c => new
            {
                FirstName = c.FirstName,
                LastName = c.LastName,
                Email = c.Email,
                Phone = c.Phone,
                Subscribtions = _context.Sales.Select(s => new
                {
                    IdSubscribtion = s.IdSubscribtionNavigation.IdSubscribtion,
                    Name = s.IdSubscribtionNavigation.Name,
                    TotalPaidAmount = _context.Payments.Where(p => p.IdSubscribtion == s.IdSubscribtion).Sum(p => p.IdSubscribtionNavigation.Price)
                }).ToList()
            }).ToListAsync();
        return Ok(result);
    }

    [HttpPut]
    public async Task<IActionResult> UpdateSubscribtion(SubscribtionDTO subscribtionDto)
    {
        var client = await _context.Clients.Where(c => c.IdClient == subscribtionDto.IdClient).FirstOrDefaultAsync();
        if (client == null)
        {
            return NotFound("Nie znaleziono klienta o danym id.");
        }

        var subscribtion = await _context.Subscribtions.Where(s => s.IdSubscribtion == subscribtionDto.IdSubscribtion)
            .FirstOrDefaultAsync();
        if (subscribtion == null)
        {
            return NotFound("Nie znaleziono subskrybcji o danym id.");
        }
        else
        {
            if (subscribtion.EndTime > DateTime.Today)
            {
                return Conflict("Subskrybcja nie jest już aktywna.");
            }
        }

        var payment = _context.Payments
            .Include(p => p.IdSubscribtionNavigation)
            .Where(p => p.Date.AddMonths(p.IdSubscribtionNavigation.RenewalPeriod) > subscribtionDto.Payment.Date)
            .FirstOrDefaultAsync();
        if (payment != null)
        {
            return Conflict("Subsckrybcja jest juz opłacona za ten okres");
        }

        await _context.Payments.AddAsync(subscribtionDto.Payment);
        await _context.SaveChangesAsync();
        

        return Ok(subscribtionDto.Payment.IdPayment);
    }
}