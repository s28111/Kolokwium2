﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

public class Sale
{
    [Key]
    public int IdSale { get; set; }
    public int IdClient { get; set; }
    public int IdSubscribtion { get; set; }
    public DateTime CreatedAt { get; set; }
    
    [ForeignKey(nameof(IdClient))]
    public Client IdClientNavigation { get; set; }
    [ForeignKey(nameof(IdSubscribtion))]
    public Subscribtion IdSubscribtionNavigation { get; set; }
}