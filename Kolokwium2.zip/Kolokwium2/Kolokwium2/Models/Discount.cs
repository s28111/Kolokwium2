﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

public class Discount
{
    [Key]
    public int IdDiscount { get; set; }
    public int Value { get;set; }
    public int IdSubscribtion { get; set; }
    public DateTime DateFrom { get; set; }
    public DateTime DateTo { get; set; }
    
    [ForeignKey(nameof(IdSubscribtion))]
    public Subscribtion IdSubscribtionNavigation { get; set; }
}