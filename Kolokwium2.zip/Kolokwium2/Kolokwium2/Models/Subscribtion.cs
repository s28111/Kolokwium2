﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium2.Models;

public class Subscribtion
{
    [Key]
    public int IdSubscribtion { get; set; }
    public string Name { get; set; }
    public int RenewalPeriod { get; set; }
    public DateTime EndTime { get; set; }
    public double Price { get; set; }

    public ICollection<Discount> Discounts { get; set; } = new List<Discount>();
    public ICollection<Payment> Payments { get; set; } = new List<Payment>();
    public ICollection<Sale> Sales { get; set; } = new List<Sale>();

}