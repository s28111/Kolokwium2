﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

public class Payment
{
    [Key]
    public int IdPayment { get; set; }
    public DateTime Date { get; set; }
    public int IdClient { get; set; }
    public int IdSubscribtion { get; set; }
    [ForeignKey(nameof(IdClient))]
    public Client IdClientNAvigation { get; set; }
    [ForeignKey(nameof(IdSubscribtion))]
    public Subscribtion IdSubscribtionNavigation { get; set; }
}